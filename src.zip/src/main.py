if __name__ == "__main__":
    from datetime import datetime
    from api import GlobalSense
    import time
    import pandas as pd
    import numpy as np

    TOTAL_ITERATIONS = 1
    MS_BREAK = 2
    
    global_sense = GlobalSense()
    
    for i in range(TOTAL_ITERATIONS):
        time_start = time.time()
        global_sense.run_tests(MS_BREAK)
        time.sleep(MS_BREAK/1000)

        # print(str(i*100/TOTAL_ITERATIONS) + "%")

        global_sense.results[12].append(time.time()-time_start)

    
    new_results = np.rot90(global_sense.results)
    
    df = pd.DataFrame(data=reversed(new_results), columns=global_sense.result_labels)
    df.to_csv("../data/results.csv")    
